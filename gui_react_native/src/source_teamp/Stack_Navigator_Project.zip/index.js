import { AppRegistry } from 'react-native';
import App from './App/containers/App';

AppRegistry.registerComponent('Stack_Navigator_Project', () => App);
