import React, { Component } from 'react';
import { View, Text } from 'react-native';
import Button from 'react-native-button';
import {ThirdScreen} from '../ScreenName';

export default class MainComponent extends Component {
    static navigationOptions = ({navigation})=>{
        let headerTitle = "Detail";
        let headerTitleStyle = { color: 'red' };
        let headerTinColor = 'white';
        let headerBackTitle = "Back";
        return { headerTitle, headerTitleStyle , headerTinColor, headerBackTitle}
    }

    render() {
        const {navigation} = this.props;
        let paramsFromMainScreen = navigation.state.params;
        return (
            <View style={{
                flex: 1,
                backgroundColor: 'mediumseagreen',
                alignItems: 'center',
                justifyContent: 'center'
            }}>
                <Text style={{ fontWeight: 'bold', fontSize: 22, color: 'white' }}>
                    This is Detail Screen
                </Text>
                <Text>
                    Param from Main Screen
                </Text>
                <Text>
                    Movie's name : {paramsFromMainScreen.name}
                </Text>
                <Text>
                    Release Year : {paramsFromMainScreen.releaseYear}
                </Text>
                <Button
                    containerStyle={{
                        padding: 10, margin: 20, width: 200, height: 45,
                        borderRadius: 10, backgroundColor: 'darkviolet'
                    }}
                    style={{ fontSize: 18, color: 'white' }}
                    onPress={() => {
                        navigation.navigate(ThirdScreen);
                    }}>
                    Navigate to Third
                </Button>
            </View>
        )
    }
}