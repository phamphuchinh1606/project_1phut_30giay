import React, {Component} from 'react';
import {View, Text} from 'react-native';

export default class MainComponent extends Component{
    render(){
        return(
            <View style={{
                flex: 1,
                backgroundColor: 'tomato',
                alignItems: 'center',
                justifyContent: 'center'
            }}>
                <Text style={{fontWeight: 'bold', fontSize: 22, color: 'white'}}>
                    This is Third Screen
                </Text>
            </View>
        )
    }
}