
import { StackNavigator } from 'react-navigation';
import MainComponent from '../components/MainComponent';
import DetailComponent from '../components/DetailComponent';
import ThirdComponent from '../components/ThirdComponent';

//Screen
import {MainScreen, DetailScreen, ThirdScreen} from '../ScreenName';

const App = StackNavigator({
    MainScreen:{
        screen: MainComponent
    },
    DetailScreen:{
        screen: DetailComponent
    },
    ThirdScreen:{
        screen: ThirdComponent,
        navigationOptions:{
            headerTitle: 'Third'
        }
    }
});

export default App;