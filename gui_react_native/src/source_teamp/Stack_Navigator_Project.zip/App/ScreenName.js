const MainScreen = "MainScreen";
const DetailScreen = "DetailScreen";
const ThirdScreen = "ThirdScreen";

export {
    MainScreen,
    DetailScreen,
    ThirdScreen
}