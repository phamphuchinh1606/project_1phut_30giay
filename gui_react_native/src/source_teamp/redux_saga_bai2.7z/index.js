import { AppRegistry } from 'react-native';
import App from './App/containers/App';

AppRegistry.registerComponent('redux_saga_bai2', () => App);
