export const ADD_MOVIE = "ADD_MOVIE";
export const FETCH_MOVEIS = "FETCH_MOVIES";

export const FETCH_SUCCEEDED = "FETCH_SECCEEDED";
export const FETCH_FAILED = "FETCH_FAILED";