import {ADD_MOVIE, FETCH_MOVIES, FETCH_SUCCEEDED, FETCH_FAILED} from './ActionType';

export const fetchMoviesAction = (sort) => {
    return{
        type: FETCH_MOVIES,
        sort: sort
    }
}

export const addMovieAction = (newMovie) => {
    return {
        type: ADD_MOVIE,
        newMovie: newMovie
    }
}

export const fetchSucceededAction = (receiveMovies) =>{
    return{
        type: FETCH_SUCCEEDED,
        receiveMovies: receiveMovies
    }
    
}

export const fetchFailedAction = (error) =>{
    return{
        type : FETCH_FAILED,
        error
     }
}