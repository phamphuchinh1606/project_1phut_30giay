import React, {Component} from 'react';
import {View, Text, TextInput, Image, FlatList, Alert} from 'react-native';
import Button from 'react-native-button';

export default class MovieComponent extends Component{
    constructor(props){
        super(props);
        this.state = {
            movieName: '',
            releaseYear: ''
        }
    }

    render(){
        return(
            <View style={{flex: 1}}>
                <Text style={{margin:10, color:'blue', fontWeight: 'bold', fontSize: 20}}>
                    Redux Saga tutorials - Movies list
                </Text>
                <Text style={{margin: 10, color:'black', fontSize: 20}}>
                    New movie information
                </Text>
                <View style={{height: 100, margin: 10}}>
                    <TextInput style={{flex: 1, borderWidth:1, borderColor:'gray', margin:5, padding: 10}}
                        onChangeText={(text)=>this.setState({movieName: text})}
                        value={this.state.movieName}
                        placeholder="Enter new movie name"/>
                    <TextInput style={{flex:1 , borderWidth: 1, borderColor:'gray', margin: 5, padding: 10, width: 120}}
                        onChangeText={(text)=>this.setState({releaseYear: text})}
                        value={this.state.releaseYear}
                        placeholder="Release year"/>
                </View>
                <View style={{height: 70, flexDirection: 'row'}}>
                    <Button
                        containerStyle={{padding: 10, margin: 10, width: 150, height: 45, borderRadius: 10, backgroundColor:'#990066'}}
                        style={{color: 'white', fontSize: 18}}
                        onPress={()=>{
                            this.props.onFetchMovies(1);
                        }}>
                        Fetch movies
                    </Button>
                    <Button
                        containerStyle={{padding: 10, margin: 10, marginLeft: 10, width: 150, height: 45, borderRadius: 10, backgroundColor:'#990066'}}
                        style={{color: 'white', fontSize: 18}}
                        onPress={()=>{
                            const {movieName, releaseYear} = this.state;
                            if(movieName.lenght == 0 || releaseYear.length == 0){
                                alert(releaseYear);
                                return;
                            }
                            this.props.onAddMovie({movieName: movieName, releaseYear: releaseYear});
                        }}>
                        Add Movie
                    </Button>
                </View>
                <FlatList
                    data={this.props.movies}
                    keyExtractor={(item)=>item.movieName}
                    renderItem={({item,index})=> <Text style={{
                        padding:10,fontWeight: 'bold',fontSize: 17, color:'white',
                        backgroundColor: (index%2 === 0) ? 'dodgerblue': 'mediumseagreen'
                    }}>
                        {`${item.movieName}, releaseYear=${item.releaseYear}`}
                    </Text>}/>
            </View>
        )
    }
}