import {ADD_MOVIE, FETCH_MOVEIS, FETCH_SUCCEEDED, FETCH_FAILED} from '../actions/ActionType';

import {put, takeLatest} from 'redux-saga/effects';
import {Api} from './Api';

function* fetchMovies(){
    try{
        const receiveMovies = yield Api.getMoviesFromApi();
        yield put({type: FETCH_SUCCEEDED, receiveMovies: receiveMovies});
    }catch(error){
        console.log(error);
        yield put({type: FETCH_FAILED, error});
    }
}

function* addNewMovie(action){
    try{
        const result = yield Api.insertNewMovieFromApi(action.newMovie);
        console.log(result);
        if(result === true){
            yield put({type: FETCH_MOVEIS, srot: 'desc'});
        }
    }catch(error){

    }
}

export function* watchFetMovies(){
    yield takeLatest(FETCH_MOVEIS,fetchMovies);
}

export function* watchAddNewMovie(){
    yield takeLatest(ADD_MOVIE, addNewMovie);
}