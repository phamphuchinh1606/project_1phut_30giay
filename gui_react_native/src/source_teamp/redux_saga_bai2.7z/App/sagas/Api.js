const urlGetMovies = "http://5ac47dbc7adeff0014d25950.mockapi.io/hello/movies";
const urlPostMivies = "http://5ac47dbc7adeff0014d25950.mockapi.io/hello/movies";

function* getMoviesFromApi(){
    let movies = [];
    yield fetch(urlGetMovies,{
        method: "GET",
        headers: {
            Accept: 'application/json',
            "Content-Type" : 'application/json'
        },
        body: '',
    }).then((response) => response.json())
    .then((responseJson) => {
        movies = responseJson;
    })
    .catch((error) => {
      console.error(error);
    });
    // const movies = yield response.status === 200 ? JSON.parse(response): [];
    // console.log(movies);
    return movies;
}

function* insertNewMovieFromApi(newMovie){
    let movies = [];
    let result = false;
    yield fetch(urlPostMivies,{
        method: "POST",
        headers: {
            "Accept": 'application/json',
            "Content-Type" : 'application/json'
        },
        body: JSON.stringify({
            movieName: newMovie.movieName,
            releaseYear: newMovie.releaseYear
        }),
    }).then((response) => response.json())
    .then((responseJson) => {
        movies = responseJson;
        console.log(movies);
        result = true;
    })
    .catch((error) => {
      console.error(error);
    });
    return result;
}

export const Api = {
    getMoviesFromApi,
    insertNewMovieFromApi
}