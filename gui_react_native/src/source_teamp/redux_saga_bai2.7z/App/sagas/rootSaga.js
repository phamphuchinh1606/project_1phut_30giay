import {delay} from 'redux-saga';
import {all, fork} from 'redux-saga/effects';
import {watchFetMovies, watchAddNewMovie} from './MovieSaga';

export default function* rootSaga(){
    yield [
        fork(watchFetMovies),
        fork(watchAddNewMovie)
    ];
}