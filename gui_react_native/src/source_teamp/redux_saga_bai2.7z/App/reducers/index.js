import {combineReducers} from 'redux';
import movieReducers from './MoviesReducer';

const allReducers = combineReducers({
    movieReducers,
});

export default allReducers;