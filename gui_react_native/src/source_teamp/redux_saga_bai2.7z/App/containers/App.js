import React, {Component} from 'react';
import {View, Text} from 'react-native';
import {createStore, applyMiddleware} from 'redux';
import { Provider } from 'react-redux';

import allReducers from '../reducers';
import MovieContainer from './MovieContainer';

import createSagaMiddleware from 'redux-saga';
import rootSaga from '../sagas/rootSaga';
const sagaMiddleware = createSagaMiddleware();
let store = createStore(allReducers, applyMiddleware(sagaMiddleware));

class App extends Component{
    render(){
        return(
            <Provider store={store}>
                <MovieContainer/>
            </Provider>
        )
    }
}
sagaMiddleware.run(rootSaga);
export default App;